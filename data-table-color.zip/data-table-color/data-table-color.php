<?php
/**
 * @package data table color
 */
/*

Plugin Name: data table color
Plugin URI: https://devles.com/
Description: This is to color post rows depending on the posts. 
Author: Rezwan Shiblu
Author URI: https://devles.com/
Version: 1.0
License: GPLv2 or later
Text Domain: data table color
tags: color, customization, administration, corsonr, remi corson
*/


/*
This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Rezwan,Sylhet, Bangladesh.

Copyright 2020.
*/


class rc_color_my_posts {
 
	/*--------------------------------------------*
	 * Constructor
	 *--------------------------------------------*/
 
	/**
	 * Initializes the plugin by setting localization, filters, and administration functions.
	 */
	function __construct() {
	
		add_action('admin_footer', array( &$this,'rc_color_my_admin_posts') );
 
	} // end constructor
 
	function rc_color_my_admin_posts(){
		?>
		<style>
			/* Color by post Status */
			.status-draft { background: #ffffe0 !important;}
			.status-future { background: #E9F2D3 !important;}
			.status-publish {background: #D3E4EC !important;}
			.status-pending { background: #D3E4ED !important;}
			.status-private { background: #FFECE6 !important;}
			.post-password-required { background: #ff9894 !important;}
			
			/* Color by author data */
			.author-self {}
			.author-other {}
			
			/* Color by post format */
			.format-aside {}
			.format-gallery {}
			.format-link {}
			.format-image {}
			.format-quote {}
			.format-status {}
			.format-video {}
			.format-audio {}
			.format-chat {}
			.format-standard {}
			
			/* Color by post category (change blog by the category slug) */
			.category-blog {}
			
			/* Color by custom post type (change xxxxx by the custom post type slug) */
			.xxxxx {}
			.type-xxxxx {}
			
			/* Color by post ID (change xxxxx by the post ID) */
			.post-xxxxx {}
			
			/* Color by post tag (change xxxxx by the tag slug) */
			.tag-xxxxx {}
			
			/* Color hAtom compliance */
			.hentry {}
			
		</style>
		<?php
	}

 
}
 
// instantiate plugin's class
$GLOBALS['color_my_posts'] = new rc_color_my_posts();